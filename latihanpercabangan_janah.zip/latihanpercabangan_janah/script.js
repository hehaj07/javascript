const nilai_matkul=prompt("Silahkan Masukan Nilai Mata Kuliah Anda!")

if (nilai_matkul>=75){
    console.log("Selamat! Anda Lulus Mata Kuliah Ini.")
}else{
    console.log("Maaf, Anda Belum Lulus Mata Kuliah Ini.Silahkan Mengulang!")
};
