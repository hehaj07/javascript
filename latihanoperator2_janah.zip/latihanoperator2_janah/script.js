//balok
let volume = "Volume balok";

let p=15
let l=4
let t=8

const v=p*l*t
console.log (volume+" "+ v)

//kubus

volume="Volume kubus"

sisi=12

const vk=sisi*sisi*sisi
console.log(volume+" "+vk)

//Tabung

volume="Volume tabung"

jari2=12
phi=22/7
t=35

const vt=(phi)*jari2*jari2*t
console.log(volume+" "+vt)

//kerucut

volume="Volume kerucut"

jari2=15
t=20

const vkr=(1/3)*phi*jari2*jari2*t
console.log(volume+" "+vkr)

//bola

volume="Volume bola"

jari2=6

const vb=(3/4)*phi*jari2*jari2*jari2
console.log(volume+" "+vb)