/*
let n=1
while (n<=50)
if ( n % 2===0)
    {console.log(n +" adalah bilangan genap");n++
   }else{ console.log(n+" adalah bilangan ganjil");n++}
*/

/*
for (let n=1; n<=50; n++) 
if (n % 2 === 0){ 
    console.log(n+" Adalah bilangan genap")}
     else {
console.log(n+" adalah bilangan ganjil")
    }
    */

/* for (let i=1; i<=100; i++)
if(i%3===0){
    console.log(i+" adalah bilangan yang habis dibagi 3")
}else{
    console.log(i+"")
}
*/

let n=50
while (n<=150){
if ( n % 4===0)
    {console.log(n +" adalah bilangan yang habis dibagi 4")
   }else{ console.log(n+" ")
}n++;
}
