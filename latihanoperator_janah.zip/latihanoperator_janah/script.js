//Luas Segitiga

let a=8
let t=16

const L=(1/2)*a*t

console.log("Luas dari segitiga "+L)

//luas persegi panjang

p=15
l=4

const L1=p*l

console.log("Luas dari persegi panjang = "+L1)

//luas Lingkaran
r=5

 const L2=(22/7)*r*r

 console.log("Luas dari lingkaran itu "+L2)

//Luas belah ketupat
d1 =12
d2 = 9

const L3=(1/2)*d1*d2

console.log("Luas dari belah ketupat adalah "+L3)

//Trapesium sama kaki

a=10
b=20
t=15

const L4=1/2*(a+b)*t

console.log("Luas trapesium = "+L4)