// Kalkulator BMI

let tinggi = prompt("Tinggi Badan Anda (Meter)");
console.log("Tinggi Badan " + tinggi + " Meter");

let bb = prompt("Berat Badan Anda (Kg)");
console.log("Berat Badan " + bb + " Kg");

let bmi=bb/(tinggi*tinggi)

console.log("Body Mass Index Anda " +bmi)
