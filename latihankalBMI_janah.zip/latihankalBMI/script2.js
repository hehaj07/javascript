//konversi suhu (s3)sangat-sangat sederhana

let csius = prompt("Masukan nilai suhu (Celcius)");
console.log("Nilai suhu dalam celcius " + csius + " °C");

let reamur = csius * (4 / 5);


console.log(csius + "°C" + " sama dengan " + reamur + "°R");

//konversi celcius ke fahrenheit
let fahrent = (csius *(9/ 5)) + 32;

console.log(csius + "°C" + " sama dengan " + fahrent + "°F");
